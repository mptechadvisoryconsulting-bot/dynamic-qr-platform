export function assertSafeRedirectUrl(value: string): URL {
  const url = new URL(value.trim());

  if (!['https:', 'http:'].includes(url.protocol)) {
    throw new Error('Unsupported URL protocol');
  }

  if (process.env.NODE_ENV === 'production' && url.protocol !== 'https:') {
    throw new Error('Production redirects must use HTTPS');
  }

  const blockedHosts = ['localhost', '127.0.0.1', '0.0.0.0'];

  if (blockedHosts.includes(url.hostname)) {
    throw new Error('Localhost/private destinations are not allowed');
  }

  return url;
}
