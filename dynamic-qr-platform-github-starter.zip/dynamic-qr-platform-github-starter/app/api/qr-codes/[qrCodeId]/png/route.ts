import { NextResponse } from 'next/server';
import QRCode from 'qrcode';
import { prisma } from '@/lib/prisma';

export async function GET(
  _request: Request,
  { params }: { params: { qrCodeId: string } }
) {
  const qrCode = await prisma.qrCode.findUnique({
    where: { id: params.qrCodeId },
  });

  if (!qrCode) {
    return new NextResponse('QR code not found', { status: 404 });
  }

  const baseUrl = process.env.APP_BASE_URL ?? 'http://localhost:3000';
  const redirectUrl = `${baseUrl}/r/${qrCode.slug}`;

  const png = await QRCode.toBuffer(redirectUrl, {
    type: 'png',
    errorCorrectionLevel: 'M',
    margin: 2,
    width: 1024,
  });

  return new NextResponse(png, {
    headers: {
      'Content-Type': 'image/png',
      'Content-Disposition': `attachment; filename="${qrCode.slug}.png"`,
    },
  });
}
