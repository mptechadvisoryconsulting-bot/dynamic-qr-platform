import { NextResponse } from 'next/server';
import QRCode from 'qrcode';
import { prisma } from '@/lib/prisma';

export async function GET(
  _request: Request,
  { params }: { params: { qrCodeId: string } }
) {
  const qrCode = await prisma.qrCode.findUnique({
    where: { id: params.qrCodeId },
  });

  if (!qrCode) {
    return new NextResponse('QR code not found', { status: 404 });
  }

  const baseUrl = process.env.APP_BASE_URL ?? 'http://localhost:3000';
  const redirectUrl = `${baseUrl}/r/${qrCode.slug}`;

  const svg = await QRCode.toString(redirectUrl, {
    type: 'svg',
    errorCorrectionLevel: 'M',
    margin: 2,
  });

  return new NextResponse(svg, {
    headers: {
      'Content-Type': 'image/svg+xml',
      'Content-Disposition': `attachment; filename="${qrCode.slug}.svg"`,
    },
  });
}
