export default function HomePage() {
  return (
    <main style={{ padding: 32, fontFamily: 'system-ui, sans-serif' }}>
      <h1>Dynamic QR Code Platform</h1>
      <p>
        This starter app provides the foundation for reusable QR codes with editable destinations.
      </p>
      <p>
        Example QR route: <code>/r/client-intake-form</code>
      </p>
    </main>
  );
}
