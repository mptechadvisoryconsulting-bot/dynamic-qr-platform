import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { assertSafeRedirectUrl } from '@/lib/urlSafety';

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  const slug = params.slug.toLowerCase().trim();

  const qrCode = await prisma.qrCode.findUnique({
    where: { slug },
  });

  if (!qrCode || qrCode.status !== 'active') {
    return new NextResponse('This QR code is not available.', { status: 404 });
  }

  if (qrCode.expiresAt && qrCode.expiresAt < new Date()) {
    return new NextResponse('This QR code has expired.', { status: 410 });
  }

  let destination: URL;

  try {
    destination = assertSafeRedirectUrl(qrCode.destinationUrl);
  } catch {
    return new NextResponse('Invalid destination URL.', { status: 400 });
  }

  await prisma.scanEvent.create({
    data: {
      qrCodeId: qrCode.id,
      clientId: qrCode.clientId,
      userAgent: request.headers.get('user-agent') ?? undefined,
      referrer: request.headers.get('referer') ?? undefined,
    },
  });

  return NextResponse.redirect(destination.toString(), 302);
}
