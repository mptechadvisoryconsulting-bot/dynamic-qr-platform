export const metadata = {
  title: 'Dynamic QR Code Platform',
  description: 'Reusable dynamic QR codes with editable destinations',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
