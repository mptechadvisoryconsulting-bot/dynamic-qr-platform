# SPEC-1-Dynamic QR Code Platform

## Background

Businesses often need to share QR codes with clients for demos, onboarding, marketing materials, product access, support portals, or event-based experiences. Static QR codes are limiting because once printed or distributed, their destination URL cannot be changed.

This design proposes a dynamic QR code platform where each QR code points to a stable redirect URL controlled by the platform. Administrators can update the destination URL at any time, allowing the same QR code to be reused across different websites, campaigns, client systems, or environments.

The MVP should support client-specific QR codes, editable destinations, usage tracking, and a professional presentation layer suitable for client delivery.

## Requirements

### Must Have

- Generate a reusable QR code that points to a stable redirect URL owned by the platform.
- Allow the QR destination URL to be changed without regenerating or reprinting the QR code.
- Support multiple clients, each with their own QR codes and destinations.
- Provide an admin dashboard for the platform owner.
- Provide client login.
- Track scan analytics.
- Support disabling QR codes.
- Provide fallback page for invalid, disabled, or expired QR codes.
- Use HTTPS.
- Validate destination URLs.

### Should Have

- Human-readable slugs.
- QR labels, descriptions, and campaign names.
- PNG and SVG downloads.
- Analytics by date range, QR code, client, country, and device.
- Role-based access control.
- Optional expiration dates.
- Destination change history.

## Method

Each QR code stores a stable redirect URL:

```text
https://qr.yourdomain.com/r/client-intake-form
```

The current destination is stored in the database and can be updated:

```text
https://forms.office.com/pages/designpagev2.aspx?origin=Notification&subpage=design&id=BsZMh8TGIU6CtlwZjeR8upEwa05tvOJOj6UaqEjR_AdUNzkySE9GM002Q1pQRkJMOE40VDRKNjAwWC4u
```

## Implementation

Build with Next.js, PostgreSQL, Prisma, and a QR generation library.

## Milestones

1. Project setup
2. Database models
3. Auth and roles
4. QR management
5. Public redirect
6. QR downloads
7. Analytics dashboard
8. Production launch

## Gathering Results

Success is measured by stable QR reuse, destination editability, analytics capture, secure access control, and reliable redirects.

## Need Professional Help in Developing Your Architecture?

Please contact me at [sammuti.com](https://sammuti.com) :)
