# Dynamic QR Code Platform

A GitHub-ready starter specification and implementation scaffold for a client-facing dynamic QR code platform.

## Purpose

This system lets you create a QR code once and change the destination URL later without reprinting the QR code.

Example QR payload:

```text
https://qr.yourdomain.com/r/client-intake-form
```

Example editable destination:

```text
https://forms.office.com/pages/designpagev2.aspx?origin=Notification&subpage=design&id=BsZMh8TGIU6CtlwZjeR8upEwa05tvOJOj6UaqEjR_AdUNzkySE9GM002Q1pQRkJMOE40VDRKNjAwWC4u
```

## Recommended Stack

- Next.js
- TypeScript
- PostgreSQL
- Prisma
- Node `qrcode` package
- Auth provider such as Clerk, Auth.js, or Auth0

## Local Setup

```bash
npm install
cp .env.example .env
npx prisma migrate dev
npm run dev
```

## Key Routes

```text
GET /r/[slug]                         Public redirect endpoint
GET /api/qr-codes/[qrCodeId]/png      Download QR as PNG
GET /api/qr-codes/[qrCodeId]/svg      Download QR as SVG
```

## Production Notes

Use a custom domain such as:

```text
https://qr.yourdomain.com
```

The QR code should encode the stable redirect URL, not the final Microsoft Forms or client website URL.
